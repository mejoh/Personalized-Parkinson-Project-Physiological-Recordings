function pf_var2str(var)
%
% Converts variable name into a string

% Michiel Dirkx
% $ParkFunC

%% function

@(x) var(1);


