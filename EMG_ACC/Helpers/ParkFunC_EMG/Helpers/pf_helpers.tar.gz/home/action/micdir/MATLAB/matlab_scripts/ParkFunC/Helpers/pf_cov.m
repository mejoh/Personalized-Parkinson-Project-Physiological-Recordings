function cov = pf_cov(x)
%
%
%
%
%

cov = std(x)/mean(x);