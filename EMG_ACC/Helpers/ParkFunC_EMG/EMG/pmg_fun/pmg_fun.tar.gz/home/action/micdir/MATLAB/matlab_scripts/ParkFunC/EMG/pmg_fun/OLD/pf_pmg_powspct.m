function pf_pmg_powspct(conf,cfg)
%
% pf_pmg_powspct preprocesses and calculates the power spectra over the
% files/conditions you specified in your configuration structure 
% (see pf_pmg_ana). It will do this using FieldTrip, so make sure you have 
% a look at this.
%
% see also pf_pmg_ana, ft_preprocessing, ft_freqanalysis
 
% �Michiel Dirkx, 2014
% $ParkFunC

%--------------------------------------------------------------------------

%% Warming Up
%--------------------------------------------------------------------------

fprintf('\n%s\n','% ---------- Frequency Analysis ------------ %')

if ~strcmpi(conf.fa.load,'yes')

%--------------------------------------------------------------------------

%% Retrieve all files
%--------------------------------------------------------------------------

fprintf('1) Collecting all files \n')

nSub    =   length(conf.sub.name);
nSess   =   length(conf.sub.sess);
Files	=	cell(nSub*nSess,1);
Sub     =   Files;  % in order to store Sub and Sess for every file name
Sess    =   Files;
Hand    =   Files;
cnt		=	1;

for a = 1:nSub
	CurSub  = conf.sub.name{a};
    CurHand = conf.sub.hand(a);
	for b = 1:nSess
		CurSess		= conf.sub.sess{b};
		CurDir		= fullfile(conf.dir.root,CurSub,CurSess,conf.dir.cutfs);
		CurFile		= pf_findfile(CurDir,conf.exp.fname,'conf',conf,'CurSub',a,'CurSess',b);
		Files{cnt}	= fullfile(CurDir,CurFile); % Save File
        Sub{cnt}    = CurSub;
        Sess{cnt}   = CurSess;
        Hand(cnt)   = CurHand;
		cnt			= cnt + 1;
		fprintf(' - Added: %s\n',CurFile)
	end
end

nFiles	=	length(Files);

%--------------------------------------------------------------------------

%% Preprocessing, select conditions and calculate power
%--------------------------------------------------------------------------

fprintf('\n2) Preprocessing and Power Calculation \n')

cnt  = 1;
cnt2 = 1;

for a = 1:nFiles
    
    % --- File --- %
    
    try
    
    CurFile     =   Files{a};
    CurSub      =   Sub{a};
    CurHand     =   Hand(a);
    CurSess     =   Sess{a};
    [path,file] =   fileparts(CurFile);
    
    [~,hdr]     =   ReadEDF(CurFile);
    Fs          =   unique(hdr.samplerate);
    
    %%%%%%%%%%%%%%%%%%%%%%%%  Stupid WorkAround %%%%%%%%%%%%%%%%%%%%%%%%%%% 
    %%% Annotations are not saved fully when cut, so load original EDF file
    if ~isempty(conf.dir.cutfs)
        [~,hdrA]       =   ReadEDF(fullfile(path,[file(1:end-7) '.edf']));
        hdr.annotation = hdrA.annotation;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('%s\n',['% - Working on subject "' CurSub '-' CurSess '" -%'])
    
    % --- Preprocessing --- %
    
    fprintf('\n2.1) Preprocessing \n')
    
    cfg.cfg_pre.dataset         = CurFile;
    data_pre.(CurSub).(CurSess) = ft_preprocessing(cfg.cfg_pre);
    
    % --- Retrieve desired conditions and cut data in nConditions --- %
    
    fprintf('\n2.2) Selecting conditions \n')
    
    cond           = pf_pmg_selcond(conf,hdr.annotation,Fs);
    nCond          = length(cond.event);
    
    for b = 1:nCond
        
        % --- Retrieve condition info --- %
        
        CurCond  =   cond.event{b};
        CurStart =   cond.starttime(b);
        CurEnd   =   CurStart+cond.duration(b);
        
        % --- Select condition data --- %
        
        CurDat              =   data_pre.(CurSub).(CurSess);
        CurDat.time         =   {CurDat.time{1}(floor(CurStart):ceil(CurEnd))};   % You may want to tweak this!
        CurDat.trial        =   {CurDat.trial{1}(:,floor(CurStart):ceil(CurEnd))};
        CurDat.sampleinfo   =   [1 length(CurDat.time{1})];
        
        % --- Load into new data structure --- %
        
        data_pre_cut.(CurSub).(CurSess).(CurCond)  =   CurDat;
    end
    
    fn  =   fieldnames(data_pre_cut.(CurSub).(CurSess));
    nFn =   length(fn);
    
    % --- Calculate Power Spectrum over all conditions --- %
    
    fprintf('\n2.3) Calculating Power Spectra \n')
        
    for c = 1:nFn
        CurFn   =   fn{c};
        CurDat  =   data_pre_cut.(CurSub).(CurSess).(CurFn);
        
        if strcmp(conf.fa.pad,'calc')
            cfg.pad = ceil(max(cellfun(@numel, CurDat.time)/CurDat.fsample));
        else
            cfg.cfg_powspct.pad = conf.fa.pad;
        end
        
        % --- cfg.toi is based on data length, deal with it here --- %
        
        if isfield(conf.fa,'toi')
            if conf.fa.toi(end)==99
                stp = conf.fa.toi(2)-conf.fa.toi(1);
                cfg.cfg_powspct.toi = CurDat.time{1}(1):stp:CurDat.time{1}(end);
            end 
        end
        
        % --- Frequency analaysis --- %
        
        data_freq.(CurSub).(CurSess).(CurFn) = ft_freqanalysis(cfg.cfg_powspct, CurDat); % Combining   
    end
    
    % --- Save succeeded Sub/Sess --- %
    
    sSub{cnt}    =   CurSub; %#ok<AGROW>
    sHand(cnt)   =   CurHand; %#ok<NASGU>
    sSess{cnt}   =   CurSess;
    cnt          =   cnt+1;    
    
    % --- If something went wrong --- %
    
    catch
        errmsg{cnt2}  =   ['Something went wrong. Skipping subject "' CurSub '-' CurSess '"'];
        warning('PFpmg:powspct',errmsg{cnt2})
		cnt2          = cnt2 +1;
    end
end

fprintf('\nDone.\n')

% --- Show error messages --- %

if exist('errmsg','var')
    fprintf('The following errors were saved: \n')
	disp(errmsg')
end

% --- Save analyzed data --- %

if strcmp(conf.fa.save,'yes')
    if ~exist(conf.dir.save.fadat,'dir'); mkdir(conf.dir.save.fadat); end
    save(fullfile(conf.dir.save.fadat,[conf.fa.filename '.mat']),'data_pre',...
         'data_pre_cut','data_freq','sSub','sHand','sSess')
    fprintf('\n%s\n',['2.4) Analysed data was saved to ' conf.dir.save.fadat])
end

%% Otherwise load pre-analysed data
%--------------------------------------------------------------------------

else
    fprintf('\n1|2) Load analysed data \n')
    file = pf_findfile(conf.dir.save.fadat,conf.fa.filename,'fullfile');
    fprintf('  - Loading file "%s"',file);
    load(file)
end
    
%--------------------------------------------------------------------------

%% Plotting
%--------------------------------------------------------------------------

fprintf('\n3) Plotting data \n')

% --- Determine plotting options --- %

switch conf.fa.fig.meth
    case 'no'
        nF      =   0;
        fprintf('- Plotting was disabled by user.\n')
    case 'powspct'
        if strcmp(conf.fa.load,'yes')
            uSub    =   conf.sub.name;
            nF      =   length(uSub);
        else
            uSub    =   unique(sSub);
            nF      =   length(uSub);
        end
end

% --- Loop Through everything --- %

for a = 1:nF
    
    CurSub   =   uSub{a};
    CurHand  =   conf.sub.hand{strcmp(conf.sub.name,CurSub)};
    
    CurData  =   data_freq.(CurSub);
    
    nPlot    =   length(conf.fa.fig.plot);
    
    % --- For every Figure --- %
    
    for b = 1:nPlot
        
        CurPlot   =  conf.fa.fig.plot{b};
        [row,col] =  size(CurPlot);
        
        cntC      =  1;
        cntR      =  1;
        cnt		  =  1;
        figPS     =  cell(row,col);
        figP      =  cell(row,col);
        figF      =  cell(row,col);
        tits      =  cell(row,col);
        chans     =  cell(row,col);
        hh        =  nan(row,col);
        
        q = figure;
        
        % --- For Every Subplot --- %
        
        for c = 1:(row*col)
            
            % --- Read Current Data --- %
            
            CurFields   =   CurPlot{cntR,cntC};
            nSp         =   length(CurFields);
            CurDat      =   CurData;
            tit         =   [CurSub '_' CurHand '_'];
            
            for d = 1:nSp;
                CurDat  =   CurDat.(CurFields{d});
                tit     =   [tit '-' CurFields{d}];
            end
            
            if strcmp(CurDat.cfg.method,'mtmconvol')
                CurDat.power     =   CurDat.powspctrm;
                CurDat.powspctrm =   nanmean(CurDat.powspctrm,3);
            end
            
            % --- Select Channels --- %
            
            if ~strcmpi(conf.fa.chan,'all')
                sel              = pf_pmg_chanselect(CurDat.label,conf.fa.chan);
                CurDat.label     = CurDat.label(sel);
                CurDat.powspctrm = CurDat.powspctrm(sel,:);
            else
                H =  strfind(CurDat.label,'EDF Annotations');
                if ~isempty([H{:}])
                    idx = find(cellfun(@isempty,H)==1);
                    CurDat.label = CurDat.label(idx);
                    CurDat.powspctrm = CurDat.powspctrm(idx,:);
                end
            end
            
            % --- Plot Data --- %
            
            hh(cntR,cntC) = subplot(row,col,c);
            nChan         =	length(CurDat.label);
            colo          =	eval([conf.fa.fig.col '(nChan)']);
            
            clear h
            for i = 1:nChan
                h(i)	= plot(CurDat.freq,CurDat.powspctrm(i,:),'col',colo(i,:));
                hold on
            end
            
            set(gca,'Xtick',CurDat.freq(1:2:end),'Xticklabel',round(CurDat.freq(1:2:end)))
            title(tit,'fontweight','b','fontsize',11,'interpreter','none');
            xlabel('Frequency (Hz)','fontweight','b')
            ylabel('Power (uV?)','fontweight','b')
            chnames = pf_pmg_channame(CurDat.label,conf.exp.chan);
            legend(h,chnames,'Location','NorthEast')
            legend('boxoff')
            xlim([CurDat.freq(1)-0.25 CurDat.freq(end)+0.25])
            
            % --- Store figure data --- %
            
            figPS{cntR,cntC}   =   CurDat.powspctrm;    % Store figure data
            figF{cntR,cntC}    =   CurDat.freq;
            tits{cntR,cntC}    =   tit;
            chans{cntR,cntC}   =   chnames; 
            
            if isfield(CurDat,'power')
                figP{cntR,cntC} =  CurDat.power;
            end 
            
            % --- Prepare for next round --- %
            
            cntC = cntC+1;
            cnt	 = cnt+1;
            
            if c == col
                cntC = 1;
                cntR = cntR + 1;
            end
        end
        
        % --- Additional Figure Adjustments --- %
        
        pf_adjustax(hh,conf.fa.fig.ax)
        
        % --- Interactively select channel/frequence if desired --- %
        
        if strcmpi(conf.fa.fig.intersel.exe,'yes')
            [chan,freq,pow,powstd,powcov] = pf_pmg_seltremorUI(hh,tits,chans,figPS,figP,figF);
            
            % --- Store the data --- %
            
            if ~exist('intersel','var')
                intersel.(CurSub)  =   [];
            end
            
            for e = 1:(row*col)
                CurFields   =   CurPlot{e};
                for d = 1:length(CurFields)
                    if d==1
                        if ~isfield(intersel.(CurSub),CurFields{d})
                            intersel.(CurSub).(CurFields{d})                    =   [];
                        end
                    elseif d>1 && d<length(CurFields)
                        if ~isfield(intersel.(CurSub).(CurFields{d-1}),CurFields{d})
                            intersel.(CurSub).(CurFields{d-1}).(CurFields{d})   =   [];
                        end
                    elseif d==length(CurFields)
                        intersel.(CurSub).(CurFields{d-1}).(CurFields{d}).chan   =   chan(e);
                        intersel.(CurSub).(CurFields{d-1}).(CurFields{d}).freq   =   freq(e);
                        intersel.(CurSub).(CurFields{d-1}).(CurFields{d}).pow    =   pow(e);
                        intersel.(CurSub).(CurFields{d-1}).(CurFields{d}).powstd =   powstd(e);
                        intersel.(CurSub).(CurFields{d-1}).(CurFields{d}).powcov =   powcov(e);
                    end
                end
            end
            % --- Save after every figure --- %
            savedir  = conf.dir.save.fadat;
            if ~exist(savedir,'dir'); mkdir(savedir); end
            save(fullfile(savedir,conf.fa.fig.intersel.filename),'intersel')
            fprintf('%s\n',['Saved data to ' fullfile(savedir,conf.fa.fig.intersel.filename)])
        end
        
        % --- Save Figure if specified --- %
        
        if strcmpi(conf.fa.fig.save,'yes')
            savedir  = conf.dir.save.faplot;
            savename = [CurSub '_' CurHand conf.fa.fig.savename{b}];
            if ~exist(savedir,'dir'); mkdir(savedir); end
            maxfig(q,1);
            print(q,conf.fa.fig.saveext,conf.fa.fig.saveres,fullfile(savedir,savename))
            fprintf('%s\n',['Saved figure to ' fullfile(savedir,savename)])
        end
        
    end
end

    
    
    
    
    
    
    
    




