function pf_pmg_ft_freqana(conf,files)
% pf_pmg_ft_freqana(conf,files) is part of the FieldTrip chapter of the
% pf_pmg_batch. Specifically it will perform a full frequency analysis of
% your PMG data.
%
% Part of pf_pmg_batch.m

% �Michiel Dirkx, 2015
% $ParkFunC, 20150429

%--------------------------------------------------------------------------

%% Initialize
%--------------------------------------------------------------------------

nFiles      =   length(files);
nPre        =   length(conf.ft.fa.cfg.preproc);
d           =   cell(nPre,1);

%--------------------------------------------------------------------------

%% Loop
%--------------------------------------------------------------------------

fprintf('\n')

for a = 1:nFiles
   
    CurFile  =   files{a};
    CurSub   =   CurFile.sub;
    CurSess  =   CurFile.sess;
    CurHand  =   CurFile.hand;
    CurPMG   =   CurFile.file;
    
    fprintf('%s\n',['Working on ' CurSub '-' CurSess])
    
    % --- Define Trial --- %
    
    cfg         =  conf.ft.fa.cfg;
    cfg.dataset =  CurPMG;
    
    cfg         =  ft_definetrial(cfg);
    
    % --- Preprocessing --- %
    
    firstappend =   1;
    
    for b = 1:nPre
        
        cfg_pre         = cfg;
        cfg_pre         = pf_concatfields(cfg_pre,cfg.preproc{b});
        
        % --- Check Append --- %
        
        if b~=nPre && any(pf_numcmp(conf.fa.chandef{b+1},conf.fa.chandef{b}))
           append  = 0; 
        else
            append = 1;
        end
        
        % --- Check if channels are already preprocessed, then preprocess --- %
        
        if b > 1 && any(pf_numcmp(conf.fa.chandef{b-1},conf.fa.chandef{b}))
            sel     = pf_strcmp(d.label,conf.ft.chans(conf.fa.chandef{b}));
            d.label = d.label(sel);
            d.trial = cellfun(@(x) x(sel,:),d.trial,'uniformoutput',0);
            cfg_pre = rmfield(cfg_pre,{'dataset' 'datafile' 'headerfile' 'trl'});         
            d       = ft_preprocessing(cfg_pre,d);
        else
            cfg_pre.channel = conf.ft.chans(conf.fa.chandef{b});
            d               = ft_preprocessing(cfg_pre);
        end
        
        % --- Append datasets --- %
        
        if firstappend && append
            data        = d;
            firstappend = 0;
        elseif ~firstappend && append
            data        =   ft_appenddata([],data,d);
        end
        
    end
    
    % --- Change labels --- %
    
    data.label = pf_pmg_channame(data.label,conf.ft.chans);
    
    % --- Retrieve conditions --- %
    
    nCond          = length(data.trial);
    cond.name      = cell(1,nCond);
    cond.starttime = nan(1,nCond);
    cond.duration  = nan(1,nCond);
    
    for b = 1:nCond 
        sel     =   [cfg.event.sample]==data.sampleinfo(b,1);
        if length(find(sel))>1
            disp('Multiple conditions with the same sample found, entering debug...')
            keyboard
        end
        cond.name{b}      =   cfg.event(sel).value;
        cond.starttime(b) =   ( cfg.event(sel).sample / data.fsample );
        cond.duration(b)  =   ( cfg.event(sel).duration / data.fsample );
    end
    
    % --- Deal with duplicate conditions --- %
    
    if length(unique(cond.name)) ~= length(cond.name)
       
       [~,~,idx] = unique(cond.name);
       uIdx              = accumarray(idx(:),(1:length(idx))',[],@(x) {sort(x)});
       sel               = cellfun(@(x) length(x)>1,uIdx);
       DupCond           = uIdx(sel);
       
       nDup              = length(DupCond); 
       
       for b = 1:nDup
            iDup         = DupCond{b};
            fprintf('%s\n',['- Found multiple conditions with name "' cond.name{iDup(1)} '"'])
            nI           = length(iDup);
            
            for c = 1:nI
                fprintf('%s\n',[num2str(c) '. ' cond.name{iDup(c)} ' with starttime ' num2str(cond.starttime(iDup(c))/60) ' minutes and duration ' num2str(cond.duration(iDup(c))) ' seconds'])
            end
            in      = input('Type index of the condition you want to include (choose one)...');
            
            % --- Remove non-selected trials --- %
            
            for c = 1:nI
                if c~=in
                    sel             =  cond.starttime==cond.starttime(iDup(c));
                    cond.name       =  cond.name(~sel);
                    cond.starttime  =  cond.starttime(~sel);
                    cond.duration   =  cond.duration(~sel);
                    data.trial      =  data.trial(~sel);
                    data.time       =  data.time(~sel);
                    data.sampleinfo =  data.sampleinfo(~sel,:);
                end
            end  
       end
    end
    
    % --- Frequency Analysis --- %
    
    cfg         =   conf.ft.fa.cfg.freq;
    DATA        =   ft_freqanalysis(cfg,data);
    DATA.cond   =   cond;
    
    % --- Store these results --- %
    
    dat.(CurSub).(CurSess) =   DATA;
    
end

keyboard


