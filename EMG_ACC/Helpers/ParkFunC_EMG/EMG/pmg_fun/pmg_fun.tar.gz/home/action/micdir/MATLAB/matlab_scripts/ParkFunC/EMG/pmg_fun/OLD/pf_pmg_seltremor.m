function [chan,freq,pow,powstd,powcov] = pf_pmg_seltremor(plots,titles,channels,powspcts,powers,freqs)
%
% pf_pmg_seltremor let's you interactively select a frequency of all the
% subplots (plots) plotted in your current figure. It will return the
% channel
%
%
%

%% Initiate parameters

[row,col]   =   size(plots);

%% Loop through subplots

figure(gcf);
chan    =   cell(row,col);
freq    =   nan(row,col);
pow     =   nan(row,col);
powstd  =   nan(row,col);
powcov  =   nan(row,col);

for a = 1:prod(row,col)
    
    % --- Select Current subplot --- %
    
    CurTit   =   titles{a};
    CurChans =   channels{a};
    
    % --- Select Channel --- %
    
    fprintf('\n%s\n',['- Subplot ' num2str(a) '("' CurTit '"): Contains the following channels:']);
    
    for b = 1:length(CurChans)
        fprintf('%s\n',['  ' num2str(b) '. ' CurChans{b}])
    end
    
    iChan   =   input('  Which channel do you want to select? ');
    chan{a} =   CurChans{iChan};
    
    fprintf('%s\n',[' Selected "' chan{a} '"'])
    
    % --- Select frequency --- %
    
    Freq    =   input('  Which frequency do you want to select ');
    iFreq   =   find(abs(freqs{a}-Freq)==min(abs(freqs{a}-Freq)));
    freq(a) =   freqs{a}(iFreq);
    
    fprintf('%s\n',[' - Selected frequency: ' num2str(freq(a)) ' Hz'])
    
    % --- Select power/CoV of this frequency --- %
    
    pow(a)  =   powspcts{a}(iChan,iFreq);
    if exist('powers','var')
        powstd(a)  =   nanstd(powers{a}(iChan,iFreq,:));
        powcov(a)  =   powstd(a)/pow(a);
    else
        fprintf('%s\n','Power over time was not found')
    end
    
    % --- Draw selection --- %
    
    subplot(plots(a))
    plot(freq(a),pow(a),'--rs','LineWidth',2,'MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',10);
    
end