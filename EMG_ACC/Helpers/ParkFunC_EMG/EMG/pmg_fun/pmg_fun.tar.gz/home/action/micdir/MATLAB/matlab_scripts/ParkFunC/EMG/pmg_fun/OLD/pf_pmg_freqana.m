function pf_pmg_freqana(conf,cfg)
%
% pf_pmg_powspct preprocesses and calculates the power spectra over the
% files/conditions you specified in your configuration structure 
% (see pf_pmg_ana). It will do this using FieldTrip, so make sure you have 
% a look at this.
%
% see also pf_pmg_ana, ft_preprocessing, ft_freqanalysis
 
% �Michiel Dirkx, 2014
% $ParkFunC

%--------------------------------------------------------------------------

%% Warming Up
%--------------------------------------------------------------------------

fprintf('\n%s\n','% ---------- Frequency Analysis ------------ %')

if ~strcmpi(conf.fa.load,'yes')

%--------------------------------------------------------------------------

%% Retrieve all files
%--------------------------------------------------------------------------

fprintf('1) Collecting all files \n')

nSub    =   length(conf.sub.name);
nSess   =   length(conf.sub.sess);
Files	=	cell(nSub*nSess,1);
Sub     =   Files;  % in order to store Sub and Sess for every file name
Sess    =   Files;
Hand    =   Files;
cnt		=	1;

for a = 1:nSub
	CurSub  = conf.sub.name{a};
    CurHand = conf.sub.hand(a);
	for b = 1:nSess
		CurSess		= conf.sub.sess{b};
		CurFile		= pf_findfile(conf.dir.prepraw,conf.exp.fname,'conf',conf,'CurSub',a,'CurSess',b);
		Files{cnt}	= fullfile(conf.dir.prepraw,CurFile); % Save File
        Sub{cnt}    = CurSub;
        Sess{cnt}   = CurSess;
        Hand(cnt)   = CurHand;
		cnt			= cnt + 1;
		fprintf(' - Added: %s\n',CurFile)
	end
end

nFiles	=	length(Files);
nPre    =   length(cfg.cfg_pre.preproc);

%--------------------------------------------------------------------------

%% Preprocessing, select conditions and calculate power
%--------------------------------------------------------------------------

fprintf('\n2) Preprocessing and Power Calculation \n')

cnt  = 1;
cnt2 = 1;

for a = 1:nFiles
    
    % --- File --- %
    
    try
    
    CurFile     =   Files{a};
    CurSub      =   Sub{a};
    CurHand     =   Hand(a);
    CurSess     =   Sess{a};
    [path,file] =   fileparts(CurFile);
    
    [~,hdr]     =   ReadEDF_shapkin(CurFile);
    Fs          =   unique(hdr.samplerate);
    
    fprintf('\n%s\n',['% - Working on subject "' CurSub '-' CurSess '" -%'])
    
    % --- Preprocessing --- %
    
    fprintf('\n2.1) Preprocessing \n')
    firstappend =   1;
    
    for b = 1:nPre
        
        cfg_pre          = cfg.cfg_pre.preproc{b};
        cfg_pre.datafile = CurFile;
        
        % --- Check Append --- %
        
        if b~=nPre && any(pf_numcmp(cfg.preproc.chandef{b+1},cfg.preproc.chandef{b}))
           append  = 0; 
        else
           append = 1;
        end
        
        % --- Check if channels are already preprocessed, then preprocess --- %
        
        if b > 1 && any(pf_numcmp(cfg.preproc.chandef{b-1},cfg.preproc.chandef{b}))
            sel     = pf_strcmp(d.label,conf.exp.chan(cfg.preproc.chandef{b}));
            d.label = d.label(sel);
            d.trial = cellfun(@(x) x(sel,:),d.trial,'uniformoutput',0);
            cfg_pre = rmfield(cfg_pre,'datafile');         
            d       = ft_preprocessing(cfg_pre,d);
        else
            cfg_pre.channel = conf.exp.chan(cfg.preproc.chandef{b});
            d               = ft_preprocessing(cfg_pre);
        end
        
        % --- Append datasets --- %
        
        if firstappend && append
            data        = d;
            firstappend = 0;
        elseif ~firstappend && append
            data        =   ft_appenddata([],data,d);
        end
        
    end
    
    data_pre.(CurSub).(CurSess) = data;
    
    % --- Retrieve desired conditions and cut data in nConditions --- %
    
    fprintf('\n2.2) Selecting conditions \n')
    
    cond           = pf_pmg_selcond(conf,hdr.annotation,Fs);
    nCond          = length(cond.event);
    
    for b = 1:nCond
        
        % --- Retrieve condition info --- %
        
        CurCond  =  cond.event{b};
        CurStart =  cond.starttime(b);
        CurEnd   =  CurStart+cond.duration(b);
        
        % --- Select condition data --- %
        
        CurDat                =   data_pre.(CurSub).(CurSess);
        if isfield(conf.fa,'prepostwin') && ~isempty(conf.fa.prepostwin)
        CurDat.cfg.pf_prepost =  conf.fa.prepostwin;
        CurStart              =  CurStart - (conf.fa.prepostwin(1)*CurDat.fsample);
        CurEnd                =  CurEnd + (conf.fa.prepostwin(2)*CurDat.fsample);
        end
        CurDat.time           =   {CurDat.time{1}(floor(CurStart):ceil(CurEnd))};   % You may want to tweak this, although it will differ from your exact marker with 1 sample at the most.
        CurDat.trial          =   {CurDat.trial{1}(:,floor(CurStart):ceil(CurEnd))};
        CurDat.sampleinfo     =   [1 length(CurDat.time{1})];
        
        % --- Load into new data structure --- %
        
        data_pre_cut.(CurSub).(CurSess).(CurCond)  =   CurDat;
    end
    
    fn  =   fieldnames(data_pre_cut.(CurSub).(CurSess));
    nFn =   length(fn);
    
    % --- Calculate Power Spectrum over all conditions --- %
    
    fprintf('\n2.3) Calculating Power Spectra \n')
        
    for c = 1:nFn
        CurFn   =   fn{c};
        CurDat  =   data_pre_cut.(CurSub).(CurSess).(CurFn);
        
        if strcmp(conf.fa.pad,'calc')
            cfg.pad = ceil(max(cellfun(@numel, CurDat.time)/CurDat.fsample));
        else
            cfg.cfg_powspct.pad = conf.fa.pad;
        end
        
        % --- cfg.toi is based on data length, deal with it here --- %
        
        if isfield(conf.fa,'toi')
            if strcmp(conf.fa.toi,'orig')
                last    =   CurDat.time{1}(end);
                stp     =   CurDat.time{1}(2)-CurDat.time{1}(1);            
            else
                last    =   conf.fa.toi(end);
                stp     =   conf.fa.toi(2)-conf.fa.toi(1);
            end
            cfg.cfg_powspct.toi = CurDat.time{1}(1):stp:last;
        end
        
        % --- Frequency analaysis --- %
        
        data_freq.(CurSub).(CurSess).(CurFn) = ft_freqanalysis(cfg.cfg_powspct, CurDat); % Combining   
    end
    
    % --- Save succeeded Sub/Sess --- %
    
    sSub{cnt}    =   CurSub; %#ok<AGROW>
    sHand(cnt)   =   CurHand; %#ok<NASGU>
    sSess{cnt}   =   CurSess;
    cnt          =   cnt+1;    
    
    % --- If something went wrong --- %
    
    catch err
        errmsg{cnt2}  =   ['Skipping subject "' CurSub '-' CurSess '". Error: ' err.message];
        warning('PFpmg:powspct',errmsg{cnt2})
		cnt2          = cnt2+1;
    end
end

fprintf('\nDone.\n')

% --- Show error messages --- %

if exist('errmsg','var')
    fprintf('The following errors were saved: \n')
	fprintf('- %s\n',errmsg{:})
end

% --- Save analyzed data --- %

if strcmp(conf.fa.save,'yes')
    fprintf('\n2.4) Saving processed data...\n')
    if ~exist(conf.dir.save.fadat,'dir'); mkdir(conf.dir.save.fadat); end
       save(fullfile(conf.dir.save.fadat,conf.fa.filename),'data_pre',...
         'data_pre_cut','data_freq','sSub','sHand','sSess')
       [~,msgid] =   lastwarn;
    if any(strfind(msgid,'sizeTooBigForMATFile'))
        fprintf('Warning detected. Now trying to save the file for "-v7.3". \nGet a coffee, this may take a while...');
        save(fullfile(conf.dir.save.fadat,conf.fa.filename),'data_pre',...
         'data_pre_cut','data_freq','sSub','sHand','sSess','-v7.3')
    end
    fprintf('\n%s\n',['- Analysed data was saved to ' fullfile(conf.dir.save.fadat,conf.fa.filename)])
end

%% Otherwise load pre-analysed data
%--------------------------------------------------------------------------

else
    fprintf('\n1|2) Load analysed data \n')
    file = pf_findfile(conf.dir.save.fadat,conf.fa.filename,'fullfile');
    fprintf('  - Loading file "%s"\n',file);
    load(file)
end
    
%--------------------------------------------------------------------------

%% Plotting
%--------------------------------------------------------------------------

fprintf('\n3) Plotting data \n')

% --- Retrieve subjects based on loaded/created data --- %

if strcmp(conf.fa.load,'yes')
    uSub    =   conf.sub.name;
else
    uSub    =   unique(sSub);
end

% --- Plotting method --- %

switch conf.fa.fig.meth
    
    %=====================================================================%
    case 'powspct'
    %=====================================================================%
    
    pf_pmg_plot_powspct(conf,data_freq,uSub)
        
    %=====================================================================%
    case 'tfr'
    %=====================================================================%    
        
    pf_pmg_plot_tfr(conf,cfg,data_freq,uSub)
        
    %=====================================================================%    
    otherwise
    %=====================================================================%    
    
    fprintf('- Plotting was disabled by user.\n')
    
end


    
    
    
    
    
    
    
    




